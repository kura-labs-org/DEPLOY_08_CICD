#!/bin/bash

set -e

docker build -t gauntlt .
